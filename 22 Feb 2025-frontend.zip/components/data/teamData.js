module.exports = [
  {
    id: 1,
    img: "/img/team/1.png",
    name: "Cody Fisher",
    designation: "Medical Assistant",
  },
  {
    id: 2,
    img: "/img/team/2.png",
    name: "Dianne Russell",
    designation: "Web Designer",
  },
  {
    id: 3,
    img: "/img/team/3.png",
    name: "Jerome Bell",
    designation: "Marketing Coordinator",
  },
  {
    id: 4,
    img: "/img/team/4.png",
    name: "Theresa Webb",
    designation: "Nursing Assistant",
  },
  {
    id: 5,
    img: "/img/team/5.png",
    name: "Cameron Williamson",
    designation: "Dog Trainer",
  },
  {
    id: 6,
    img: "/img/team/6.png",
    name: "Courtney Henry",
    designation: "Medical Assistant",
  },
  {
    id: 7,
    img: "/img/team/7.png",
    name: "Theresa Williamson",
    designation: "Web Designer",
  },
];
